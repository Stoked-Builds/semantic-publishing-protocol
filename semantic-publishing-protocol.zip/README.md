# Semantic Publishing Protocol (SPP)

Welcome to the open standard for AI-native, consent-based, semantically-structured content publishing.
