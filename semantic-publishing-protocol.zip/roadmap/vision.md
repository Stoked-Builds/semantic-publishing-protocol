# The Stoked Protocol

Our manifesto for a new kind of web.