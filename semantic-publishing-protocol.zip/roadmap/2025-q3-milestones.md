# Q3 2025 Milestones

Initial rollout plan for SPP.