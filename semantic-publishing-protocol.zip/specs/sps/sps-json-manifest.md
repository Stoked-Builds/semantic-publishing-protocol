# SPS JSON Manifest

Structure of `.sps.json` files.