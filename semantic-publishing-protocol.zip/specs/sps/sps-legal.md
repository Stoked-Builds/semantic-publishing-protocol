# Legal Metadata for SPS

Define terms of use, reuse, and monetisation.