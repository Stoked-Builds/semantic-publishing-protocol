# Ad Scorecard UI

Show users why an ad was shown.