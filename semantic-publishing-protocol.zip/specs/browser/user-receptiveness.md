# User Receptiveness Model

How the browser scores user openness to ads.