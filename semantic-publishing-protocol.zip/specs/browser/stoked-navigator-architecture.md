# Stoked Navigator Architecture

AI-native browser design.