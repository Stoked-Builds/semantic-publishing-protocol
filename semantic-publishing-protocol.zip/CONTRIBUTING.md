## How to Contribute

Pull requests welcome. Please read the spec before contributing.