MIT License

[Full license text here]